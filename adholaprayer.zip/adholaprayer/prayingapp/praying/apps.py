from django.apps import AppConfig


class PrayingConfig(AppConfig):
    name = 'praying'
