from django.core import validators
from django import forms
from .models import Pray_tb

# class Register_prayer(forms.ModelForm):
#     class Meta:
#         model = Pray_tb
#         fields = ['_ALL_']
        


